﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CInfo : MonoBehaviour
{
	public bool isPlayer = false;
	private float health = 10;
	private float stamina = 50;
	private string leftHandEquip = "Empty";
	private string rightHandEquip = "Empty";

	void Start ()
	{
		
	}
	
	void Update ()
	{
		
	}
}
